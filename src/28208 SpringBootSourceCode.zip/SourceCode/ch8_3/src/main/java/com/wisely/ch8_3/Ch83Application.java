package com.wisely.ch8_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch83Application {

    public static void main(String[] args) {
        SpringApplication.run(Ch83Application.class, args);
    }
    
 
}
