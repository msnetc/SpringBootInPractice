sleep 90
java -Djava.security.egd=file:/dev/./urandom -jar /app/app.jar