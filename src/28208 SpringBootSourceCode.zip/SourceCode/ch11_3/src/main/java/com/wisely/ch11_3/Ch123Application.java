package com.wisely.ch11_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch123Application {

    public static void main(String[] args) {
        SpringApplication.run(Ch123Application.class, args);
    }
}
