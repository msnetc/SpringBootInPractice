package com.wisely.ch8_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch84Application {

    public static void main(String[] args) {
        SpringApplication.run(Ch84Application.class, args);
    }
}
