package com.wisely.highlight_spring4.ch3.conditional;

public interface ListService {
	public String showListCmd();
}
