package com.wisely.highlight_spring4.ch3.annotation;

@WiselyConfiguration("com.wisely.highlight_spring4.ch3.annotation")
public class DemoConfig {

}
