package com.wisely.highlight_spring4.ch3.fortest;

public class TestBean {
	private String content;

	public TestBean(String content) {
		super();
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}
